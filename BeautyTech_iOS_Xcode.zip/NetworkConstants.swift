import Foundation

struct NetworkConstants {
    static let baseURL = "http://<YOUR_BACKEND_HOST>:8000" // ضع هنا URL الـbackend المحلي/المستضاف
    static let diagnoseEndpoint = "/diagnose"
    static let loginEndpoint = "/auth/login" // إذا أضفت endpoint تسجيل
}
