import Foundation

struct AIRecommendation: Codable, Identifiable {
    var id: String { product_id ?? UUID().uuidString }
    let product_id: String?
    let name: String
    let reason: String?
}

struct AIResult: Codable {
    let source: String?
    let skin_type: String?
    let issues: [String]?
    let confidence: Double?
    let recommendations: [AIRecommendation]?

    enum CodingKeys: String, CodingKey {
        case source, skin_type, issues, confidence, recommendations
    }
}
