BeautyTech iOS SwiftUI Starter (MVP)

Files included:
- AppEntry.swift
- Theme.swift
- NetworkConstants.swift
- Models.swift
- AuthManager.swift
- NetworkManager.swift
- Views/ (Splash, Onboarding, Login, CameraCapture, AIResults, Recommendations)
- Views/Components/ImagePicker.swift

Instructions:
1. Open Xcode (13+). Create a new SwiftUI project and replace the generated content with these files, or add them into the project folder.
2. Add color assets in Assets.xcassets: bg (#FFFFFF), textPrimary (#000000), gold (#C8A34A), muted (#E5E5E5), card (#FFFFFF or slight gray).
3. Set NetworkConstants.baseURL to your backend host (e.g., http://192.168.1.5:8000).
4. Add Info.plist keys:
   - NSCameraUsageDescription
   - NSPhotoLibraryUsageDescription
5. Build & Run on a real device for camera functionality.
6. Backend: run the FastAPI backend (BeautyTech_Starter_v3) and ensure /diagnose endpoint is reachable.

Notes:
- This is MVP starter code. Replace mock login with real auth and improve secure storage for tokens (Keychain).
- Adjust AIResult model to match your backend JSON schema.
