import SwiftUI

extension Color {
    static let theme = Theme()
}
struct Theme {
    let background = Color("bg") // أبيض
    let primaryText = Color("textPrimary") // أسود
    let gold = Color("gold") // ذهبي ناعم
    let muted = Color("muted")
    let card = Color("card")
}
