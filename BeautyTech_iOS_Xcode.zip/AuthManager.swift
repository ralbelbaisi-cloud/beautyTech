import Foundation
import Combine

class AuthManager: ObservableObject {
    @Published var isLoggedIn: Bool = false
    @Published var token: String? = nil

    init() {
        token = UserDefaults.standard.string(forKey: "jwt_token")
        isLoggedIn = token != nil
    }

    func login(email: String, password: String, completion: @escaping (Bool, String?) -> Void) {
        guard !email.isEmpty && !password.isEmpty else {
            completion(false, "املأ الحقول")
            return
        }
        DispatchQueue.main.asyncAfter(deadline: .now()+0.6) {
            let mock = "mock-jwt-token-\(UUID().uuidString)"
            self.token = mock
            UserDefaults.standard.setValue(mock, forKey: "jwt_token")
            self.isLoggedIn = true
            completion(true, nil)
        }
    }

    func logout() {
        token = nil
        isLoggedIn = false
        UserDefaults.standard.removeObject(forKey: "jwt_token")
    }
}
