import SwiftUI

@main
struct BeautyTechApp: App {
    @StateObject var auth = AuthManager()
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(auth)
        }
    }
}

struct RootView: View {
    @EnvironmentObject var auth: AuthManager
    @State private var showOnboarding = !UserDefaults.standard.bool(forKey: "didShowOnboarding")

    var body: some View {
        Group {
            if showOnboarding {
                OnboardingView(dismissAction: {
                    UserDefaults.standard.setValue(true, forKey: "didShowOnboarding")
                    showOnboarding = false
                })
            } else if !auth.isLoggedIn {
                LoginView()
            } else {
                TabView {
                    CameraCaptureView()
                        .tabItem {
                            Image(systemName: "camera")
                            Text("تحليل")
                        }
                    RecommendationsView()
                        .tabItem {
                            Image(systemName: "sparkles")
                            Text("توصيات")
                        }
                }
            }
        }
        .accentColor(Color.theme.gold)
    }
}
