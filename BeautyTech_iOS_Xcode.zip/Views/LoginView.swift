import SwiftUI

struct LoginView: View {
    @EnvironmentObject var auth: AuthManager
    @State private var email = ""
    @State private var password = ""
    @State private var isLoading = false
    @State private var errorMsg: String?

    var body: some View {
        VStack(spacing: 16) {
            Spacer()
            Text("مرحبًا بك في BeautyTech")
                .font(.title)
                .fontWeight(.bold)
            TextField("البريد الإلكتروني", text: $email)
                .keyboardType(.emailAddress)
                .autocapitalization(.none)
                .padding()
                .background(Color.theme.card)
                .cornerRadius(8)
            SecureField("كلمة المرور", text: $password)
                .padding()
                .background(Color.theme.card)
                .cornerRadius(8)
            if let e = errorMsg {
                Text(e).foregroundColor(.red).font(.footnote)
            }
            Button(action: {
                isLoading = true
                auth.login(email: email, password: password) { ok, err in
                    DispatchQueue.main.async {
                        isLoading = false
                        if !ok { errorMsg = err }
                    }
                }
            }) {
                Text(isLoading ? "جاري ...": "تسجيل الدخول")
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.theme.primaryText)
                    .cornerRadius(8)
            }
            Spacer()
            HStack {
                Text("لا تملك حساب؟")
                Button("سجل الآن") { /* في MVP نحتفظ بالمشهد كـ stub */ }
            }.font(.footnote)
        }
        .padding()
        .background(Color.theme.background.edgesIgnoringSafeArea(.all))
    }
}
