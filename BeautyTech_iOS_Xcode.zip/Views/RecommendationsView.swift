import SwiftUI

struct RecommendationsView: View {
    let sample: [AIRecommendation] = [
        AIRecommendation(product_id: "P001", name: "مرطب نهاري SPF30", reason: "مرطب وحماية شمسية"),
        AIRecommendation(product_id: "P002", name: "سيروم فيتامين C", reason: "تفتيح موضعي وتقليل التصبغات"),
        AIRecommendation(product_id: "P003", name: "قناع مهدئ ليلي", reason: "تهدئة البشرة الحساسة")
    ]
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 16) {
                    ForEach(sample) { item in
                        HStack {
                            RoundedRectangle(cornerRadius: 8).fill(Color.theme.card).frame(width: 84, height: 84).overlay(
                                Image(systemName: "leaf").foregroundColor(Color.theme.gold)
                            )
                            VStack(alignment: .leading) {
                                Text(item.name).font(.headline).foregroundColor(Color.theme.primaryText)
                                Text(item.reason ?? "").font(.caption).foregroundColor(Color.theme.muted)
                            }
                            Spacer()
                            Button(action: {
                                // subscribe upsell / buy
                            }) {
                                Text("اشترِ الآن")
                                    .padding(8)
                                    .background(Color.theme.primaryText)
                                    .foregroundColor(.white)
                                    .cornerRadius(8)
                            }
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(12)
                        .shadow(color: Color.black.opacity(0.04), radius: 6, x: 0, y: 2)
                    }
                }
                .padding()
            }
            .navigationTitle("توصيات الجمال")
        }
    }
}
