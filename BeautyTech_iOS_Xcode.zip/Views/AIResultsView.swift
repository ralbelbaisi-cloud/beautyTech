import SwiftUI

struct AIResultsView: View {
    let result: AIResult
    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                HStack {
                    VStack(alignment: .leading) {
                        Text("نوع البشرة")
                            .font(.subheadline)
                            .foregroundColor(Color.theme.muted)
                        Text(result.skin_type ?? "غير محدد")
                            .font(.title2)
                            .fontWeight(.bold)
                            .foregroundColor(Color.theme.primaryText)
                    }
                    Spacer()
                    Circle()
                        .fill(Color.theme.gold)
                        .frame(width: 60, height: 60)
                        .overlay(Text(String(format: "%.0f%%", (result.confidence ?? 0)*100)).font(.caption).foregroundColor(.white))
                }
                .padding()
                .background(Color.theme.card)
                .cornerRadius(12)

                if let issues = result.issues, !issues.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("المشكلات المكتشفة").font(.subheadline).foregroundColor(Color.theme.muted)
                        ForEach(issues, id: \\ .self) { it in
                            HStack {
                                Image(systemName: "exclamationmark.triangle.fill").foregroundColor(.orange)
                                Text(it).foregroundColor(Color.theme.primaryText)
                                Spacer()
                            }.padding(.vertical, 6)
                        }
                    }.padding().background(Color.theme.card).cornerRadius(12)
                }

                if let recs = result.recommendations, !recs.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("توصيات المنتج").font(.subheadline).foregroundColor(Color.theme.muted)
                        ForEach(recs) { r in
                            HStack {
                                VStack(alignment: .leading) {
                                    Text(r.name).fontWeight(.semibold).foregroundColor(Color.theme.primaryText)
                                    if let reason = r.reason { Text(reason).font(.caption).foregroundColor(Color.theme.muted) }
                                }
                                Spacer()
                                Button(action: {
                                    // TODO: add to cart / show product detail
                                }) {
                                    Text("عرض")
                                        .padding(8)
                                        .background(Color.theme.primaryText)
                                        .foregroundColor(.white)
                                        .cornerRadius(8)
                                }
                            }.padding(.vertical, 6)
                        }
                    }.padding().background(Color.theme.card).cornerRadius(12)
                }

                Spacer()
            }.padding()
        }.navigationTitle("نتيجة التحليل")
    }
}
