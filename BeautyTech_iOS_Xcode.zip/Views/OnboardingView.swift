import SwiftUI

struct OnboardingView: View {
    let dismissAction: () -> Void
    @State private var page = 0
    var body: some View {
        VStack {
            TabView(selection: $page) {
                OnboardPage(image: "sparkles", title: "تشخيص ذكي لبشرتك", subtitle: "تحليل مخصص يأخذ بعين الاعتبار مناخ الخليج")
                    .tag(0)
                OnboardPage(image: "drop.fill", title: "منتجات موثوقة", subtitle: "صناديق مخصصة بناءً على نتيجة التحليل")
                    .tag(1)
                OnboardPage(image: "leaf.fill", title: "استدامة", subtitle: "برنامج استرجاع العبوات وصندوق صديق للبيئة")
                    .tag(2)
            }
            .tabViewStyle(PageTabViewStyle(indexDisplayMode: .always))
            .indexViewStyle(PageIndexViewStyle(backgroundDisplayMode: .always))
            Button(action: {
                dismissAction()
            }) {
                Text("ابدأ الآن")
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.theme.primaryText)
                    .cornerRadius(10)
                    .padding()
            }
        }
    }
}

struct OnboardPage: View {
    var image: String; var title: String; var subtitle: String
    var body: some View {
        VStack(spacing: 20) {
            Spacer()
            Image(systemName: image).resizable().frame(width: 90, height: 90).foregroundColor(Color.theme.gold)
            Text(title).font(.title2).bold().foregroundColor(Color.theme.primaryText)
            Text(subtitle).multilineTextAlignment(.center).foregroundColor(Color.theme.muted).padding(.horizontal, 24)
            Spacer()
        }
    }
}
