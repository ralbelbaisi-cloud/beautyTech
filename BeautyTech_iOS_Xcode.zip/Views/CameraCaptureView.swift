import SwiftUI

struct CameraCaptureView: View {
    @State private var showPicker = false
    @State private var image: UIImage? = nil
    @State private var analyzing = false
    @State private var result: AIResult? = nil
    @State private var showConsent = false
    @State private var errorMsg: String?

    var body: some View {
        NavigationView {
            VStack(spacing: 16) {
                Spacer()
                if let img = image {
                    Image(uiImage: img).resizable().scaledToFit().frame(height: 320).cornerRadius(12).shadow(radius: 6)
                } else {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.theme.card)
                        .frame(height: 320)
                        .overlay(Text("لم يتم اختيار صورة بعد").foregroundColor(Color.theme.muted))
                }

                HStack {
                    Button(action: { showPicker = true }) {
                        HStack {
                            Image(systemName: "photo")
                            Text("اختر من الألبوم")
                        }.padding().frame(maxWidth: .infinity).background(Color.theme.card).cornerRadius(10)
                    }
                    Button(action: { showPicker = true }) {
                        HStack {
                            Image(systemName: "camera")
                            Text("التقاط صورة")
                        }.padding().frame(maxWidth: .infinity).background(Color.theme.primaryText).foregroundColor(.white).cornerRadius(10)
                    }
                }.padding(.horizontal)

                if analyzing {
                    ProgressView("جارٍ التحليل...").padding()
                }

                if let r = result {
                    NavigationLink(destination: AIResultsView(result: r)) {
                        Text("عرض النتائج")
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.theme.gold)
                            .cornerRadius(10)
                            .padding(.horizontal)
                    }
                } else {
                    Button(action: {
                        guard image != nil else { errorMsg = "اختر صورة أولاً"; return }
                        showConsent = true
                    }) {
                        Text("حلل الصورة")
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.theme.primaryText)
                            .cornerRadius(10)
                            .padding(.horizontal)
                    }
                }

                if let e = errorMsg {
                    Text(e).foregroundColor(.red).font(.footnote)
                }

                Spacer()
            }
            .navigationTitle("تحليل البشرة")
            .sheet(isPresented: $showPicker) {
                ImagePicker(sourceType: .photoLibrary) { img in
                    if let img = img {
                        self.image = img
                        self.result = nil
                    }
                }
            }
            .alert(isPresented: $showConsent) {
                Alert(title: Text("موافقة الخصوصية"),
                      message: Text("أوافق على رفع صوري واستخدامها لتحليل البشرة داخل BeautyTech. سيتم تخزين الصور مشفّرة ولن تُشارك بدون موافقتي."),
                      primaryButton: .default(Text("موافق"), action: { analyzeImage() }),
                      secondaryButton: .cancel())
            }
        }
    }

    func analyzeImage() {
        guard let img = image else { return }
        analyzing = true
        NetworkManager.shared.uploadImageForDiagnosis(image: img) { res in
            DispatchQueue.main.async {
                self.analyzing = false
                switch res {
                case .success(let r):
                    self.result = r
                case .failure(let err):
                    self.errorMsg = "فشل التحليل: \(err.localizedDescription)"
                }
            }
        }
    }
}
