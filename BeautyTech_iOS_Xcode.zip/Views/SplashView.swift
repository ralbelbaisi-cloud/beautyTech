import SwiftUI

struct SplashView: View {
    @State private var animate = false
    var body: some View {
        ZStack {
            Color.theme.background.edgesIgnoringSafeArea(.all)
            VStack(spacing: 20) {
                Text("BeautyTech")
                    .font(.system(size: 34, weight: .bold, design: .serif))
                    .foregroundColor(Color.theme.primaryText)
                Text("حيث تبدأ جمالك العلمي")
                    .font(.system(size: 16, weight: .regular))
                    .foregroundColor(Color.theme.muted)
                Image(systemName: "sparkles")
                    .resizable()
                    .frame(width: 80, height: 80)
                    .foregroundColor(Color.theme.gold)
                    .scaleEffect(animate ? 1.05 : 0.9)
                    .opacity(animate ? 1 : 0.6)
            }
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 1.2).repeatForever(autoreverses: true)) {
                animate.toggle()
            }
        }
    }
}
