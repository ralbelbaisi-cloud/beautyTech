import Foundation
import UIKit

class NetworkManager {
    static let shared = NetworkManager()
    private init(){}

    func uploadImageForDiagnosis(image: UIImage, completion: @escaping (Result<AIResult, Error>) -> Void) {
        guard let url = URL(string: NetworkConstants.baseURL + NetworkConstants.diagnoseEndpoint) else {
            completion(.failure(NSError(domain: "InvalidURL", code: 0)))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"

        let boundary = "Boundary-\(UUID().uuidString)"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        guard let imageData = image.jpegData(compressionQuality: 0.7) else {
            completion(.failure(NSError(domain: "ImageEncoding", code: 0)))
            return
        }

        var body = Data()
        let filename = "photo.jpg"
        let mimetype = "image/jpeg"

        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"file\"; filename=\"\(filename)\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: \(mimetype)\r\n\r\n".data(using: .utf8)!)
        body.append(imageData)
        body.append("\r\n".data(using: .utf8)!)
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)

        request.httpBody = body

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let e = error { completion(.failure(e)); return }
            guard let d = data else {
                completion(.failure(NSError(domain: "NoData", code: 0))); return
            }
            do {
                let decoder = JSONDecoder()
                let result = try decoder.decode(AIResult.self, from: d)
                completion(.success(result))
            } catch {
                if let txt = String(data: d, encoding: .utf8) {
                    print("Raw response: \(txt)")
                }
                completion(.failure(error))
            }
        }
        task.resume()
    }
}
